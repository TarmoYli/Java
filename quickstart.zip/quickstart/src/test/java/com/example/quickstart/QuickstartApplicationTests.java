package com.example.quickstart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickstartApplicationTests {

	@Test
	void contextLoads() {
	}

}
